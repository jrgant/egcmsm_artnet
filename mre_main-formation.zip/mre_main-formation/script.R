# %% PACKAGES ------------------------------------------------------------------

pacman::p_load(magrittr,
               data.table,
               summarytools,
               stringr)

netstats <- readRDS("netstats.Rds")

str(netstats)

# %% TECHNICAL PARAMETERS ------------------------------------------------------

mcmc.maxiterations <- 500
use_ncores <- 4


# %% NETWORK ESTIMATION --------------------------------------------------------

suppressMessages(library("EpiModelHIV"))

# Initialize network
nw <- network.initialize(netstats$demog$num, directed = F)
nw <- set.vertex.attribute(nw, "race.eth", netstats$attr$race)
nw <- set.vertex.attribute(nw, "age", netstats$attr$age)
nw <- set.vertex.attribute(nw, "age.wk", netstats$attr$age.wk)
nw <- set.vertex.attribute(nw, "age5", netstats$attr$age5)
nw <- set.vertex.attribute(nw, "deg.main", netstats$attr$deg.main)
nw <- set.vertex.attribute(nw, "deg.casl", netstats$attr$deg.casl)
nw <- set.vertex.attribute(nw, "role.class", netstats$attr$role.class)

# %% MAIN PARTNERSHIPS ---------------------------------------------------------

main_formation <- ~edges +
                  nodefactor("race.eth", levels = -1) +
                  nodefactor("age5", levels = -1) +
                  nodefactor("deg.casl", levels = -1) +
                  concurrent +
                  nodematch("race.eth") +
                  nodematch("age5") +
                  nodematch("role.class", levels = c("R", "I"))


netstats_main <-
  with(netstats$netmain,
    c(edges = edges,
      nodefactor_race = nodefactor_race[-1],
      nodefactor_age5 = nodefactor_age5[-1],
      nodefactor_degcasl = nodefactor_degcasl[-1],
      concurrent = concurrent,
      nodematch_race.eth = nodematch_race.eth,
      nodematch_age5 = nodematch_age5,
      nodematch_ai.role = 0
))

netstats_main <- unname(netstats_main)
netstats_main

# @TODO 2020-01-28
# add mortality rates
coef_diss_main <- dissolution_coefs(~offset(edges),
                                    netstats$netmain$durat_wks)

netest_main <- netest(
       nw = nw,
       formation = main_formation,
       target.stats = netstats_main,
       coef.diss = coef_diss_main,
       edapprox = T,
       set.control.ergm = control.ergm(MCMLE.maxit = mcmc.maxiterations)
       )

summary(netest_main)
